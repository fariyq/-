document.addEventListener("DOMContentLoaded", function () {
    console.log("Invoice App is ready!");
});
